let num=Number(prompt("Escribe un numero"));
if(num>0){
    document.write("El numero es positivo");   
}else{
    document.write("El numero es negativo");
}
