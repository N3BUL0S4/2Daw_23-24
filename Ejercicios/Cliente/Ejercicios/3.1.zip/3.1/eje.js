alert("Ruben Sanchez Garcia");
document.write("1710250@alu.murciaeduca.es");
console.log("Texto Secreto");