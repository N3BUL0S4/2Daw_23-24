export class empleado {
    nombre:string
    apellidos:string
    documento:string
    salario:number

    constructor(nombre:string,apellidos:string,documento:string,salario:number) {
        this.nombre=nombre
        this.apellidos=apellidos
        this.documento=documento
        this.salario=salario
    }

}