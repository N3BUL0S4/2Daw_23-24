export class gasto {
    gasto:string
    cantidad:number

    constructor(gasto:string,cantidad:number) {
        this.gasto=gasto
        this.cantidad=cantidad
    }
}