let num=Number(prompt("Escribe un numero"));
if(num>0){
    document.write(num);   
}else{
    document.write(num*-1);
}
