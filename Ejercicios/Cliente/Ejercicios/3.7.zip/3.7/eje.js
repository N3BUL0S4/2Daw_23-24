let SN=prompt("¿Eres culpable?");
if(SN=="si"){
    document.write("Eres Culpable");
}else{
    document.write("No eres Culpable");
}