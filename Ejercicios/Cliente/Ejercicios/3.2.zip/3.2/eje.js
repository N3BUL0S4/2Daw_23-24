let num1=Number(prompt("Introduce el 1 numero"));
let num2=Number(prompt("Introduce el 2 numero"));

//suma  

let suma=num1+num2;
document.write("La suma es: "+suma);
document.write("<hr>");

//resta

let resta=num1-num2;
document.write("La resta es: "+resta);
document.write("<hr>");


//multiplicacion

let multiplicacion=num1*num2;
document.write("La multiplicacion es: "+multiplicacion);
document.write("<hr>");


//division

let division=num1/num2;
document.write("La division es: "+division);
document.write("<hr>");

//Resto de Division

let resto=num1%num2;
document.write("La resto de division es: "+resto);
document.write("<hr>");