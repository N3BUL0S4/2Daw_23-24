let num=Number(prompt("Escribe un numero"));
if(num%2==0){
    document.write("Es Par"+num);   
}else{
    document.write("Es impar"+num);
}
