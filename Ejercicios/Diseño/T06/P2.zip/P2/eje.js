colores = ["naranja", "rojo", "azul", "verde", "amarillo"]
c1=1;
c2=0;
document.addEventListener("click", function() {
    if (c1 >= 5) {
        c1=0
    }
    console.log("Fuera"+c1)
    console.log("Dentro"+c2)
    document.querySelector("#dentro").className=colores[c1]
    document.querySelector("#fuera").className=colores[c2]
    c2=c1
    c1++
})